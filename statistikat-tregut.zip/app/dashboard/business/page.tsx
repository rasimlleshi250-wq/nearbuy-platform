"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import { db } from "@/lib/firebase/config";
import { doc, getDoc, updateDoc, collection, query, where, getDocs, serverTimestamp } from "firebase/firestore";
import { getTotalStats, getLast30DaysStats, getMonthComparison } from "@/lib/firebase/analytics";
import MarketInsights from "./MarketInsights";
import Link from "next/link";
import { getSubscriptionState, formatDate } from "@/lib/subscription";
import { notify } from "@/lib/notify";
import { PLANS as PLAN_DEFS, PLAN_ORDER, getEffectivePlan, hasStats, normalizePlanId, formatEur } from "@/lib/plans";

interface Business {
  id: string;
  name: string;
  city: string;
  category: string;
  subscription: string;
  verified: boolean;
  logo?: string;
  phone?: string;
  address?: string;
  description?: string;
  requestedPlan?: string;
  planStatus?: string;
  subscriptionEnd?: unknown;
}

interface DayData { date: string; count: number; }


function MiniChart({ data, color }: { data: DayData[]; color: string }) {
  if (!data.length) return <div className="chart-empty">Pa të dhëna</div>;
  const max = Math.max(...data.map(d => d.count), 1);
  const last30 = [...data].sort((a, b) => a.date.localeCompare(b.date)).slice(-14);
  return (
    <div className="chart-bars">
      {last30.map((d, i) => (
        <div key={i} className="chart-bar-wrap" title={`${d.date}: ${d.count}`}>
          <div className="chart-bar" style={{ height: `${(d.count / max) * 100}%`, background: color }} />
        </div>
      ))}
    </div>
  );
}

export default function BusinessOverviewPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [business, setBusiness] = useState<Business | null>(null);
  const [loading, setLoading] = useState(true);
  const [productCount, setProductCount] = useState(0);
  const [docId, setDocId] = useState<string | null>(null);
  const [requesting, setRequesting] = useState(false);
  const [requestedSuccess, setRequestedSuccess] = useState("");

  // Analytics state
  const [totalViews, setTotalViews] = useState(0);
  const [totalContacts, setTotalContacts] = useState(0);
  const [totalMaps, setTotalMaps] = useState(0);
  const [viewsData, setViewsData] = useState<DayData[]>([]);
  const [contactsData, setContactsData] = useState<DayData[]>([]);
  const [mapsData, setMapsData] = useState<DayData[]>([]);
  const [myProductIds, setMyProductIds] = useState<string[]>([]);
  const [comparison, setComparison] = useState<{ thisMonth: { views: number; contacts: number }; lastMonth: { views: number; contacts: number } } | null>(null);

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      try {
        let bid = user.uid;
        const bizSnap = await getDoc(doc(db, "businesses", user.uid));
        if (bizSnap.exists()) {
          setBusiness({ id: bizSnap.id, ...bizSnap.data() } as Business);
          setDocId(user.uid);
        } else {
          const q = query(collection(db, "businesses"), where("ownerUID", "==", user.uid));
          const snap = await getDocs(q);
          if (!snap.empty) {
            setBusiness({ id: snap.docs[0].id, ...snap.docs[0].data() } as Business);
            setDocId(snap.docs[0].id);
            bid = snap.docs[0].id;
          } else {
            router.replace("/dashboard/business/setup");
            return;
          }
        }

        // Produkte
        const pq = query(collection(db, "business_products"), where("businessId", "==", bid));
        const psnap = await getDocs(pq);
        setProductCount(psnap.size);
        setMyProductIds(psnap.docs.map(d => String(d.data().productId || "")).filter(Boolean));

        // Analytics bazë (gjithmonë)
        const total = await getTotalStats("businesses", bid);
        setTotalViews(total.totalViews);
        setTotalContacts(total.totalContacts);

        // Merr planin nga biznesi — vetëm nëse abonimi është aktiv (i aprovuar dhe pa skaduar)
        const bizData = bizSnap.exists() ? bizSnap.data() : (await getDoc(doc(db, "businesses", bid))).data();
        const st = getSubscriptionState(bizData || null);
        const eff = getEffectivePlan(bizData || null);
        const isAdvancedOrPro = hasStats(eff, "charts");

        // Përmbledhja mujore — për çdo plan aktiv
        if (st.active && hasStats(eff, "monthly")) {
          try { setComparison(await getMonthComparison("businesses", bid)); } catch {}
        }

        if (isAdvancedOrPro) {
          const stats30 = await getLast30DaysStats("businesses", bid);
          setViewsData(stats30.views);
          setContactsData(stats30.contacts);
          setMapsData(stats30.maps);
          setTotalMaps(stats30.totalMaps);
        }


      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user, router]);

  const handleRequestPlan = async (planId: string) => {
    if (!docId || !business) return;
    if (business.requestedPlan === planId && business.planStatus === "pending") return;
    setRequesting(true);
    try {
      await updateDoc(doc(db, "businesses", docId), { requestedPlan: planId, planStatus: "pending", planRequestedAt: serverTimestamp() });
      notify("plan_request", docId, "business");
      setBusiness(p => p ? { ...p, requestedPlan: planId, planStatus: "pending" } : p);
      setRequestedSuccess(planId);
      setTimeout(() => setRequestedSuccess(""), 4000);
    } catch (e) { console.error(e); }
    finally { setRequesting(false); }
  };

  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "60vh" }}>
      <div className="nb-spin" />
      <style>{`.nb-spin{width:24px;height:24px;border:2px solid rgba(249,115,22,0.2);border-top-color:#f97316;border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  if (!business) return null;

  const effPlan = getEffectivePlan(business as unknown as Record<string, unknown>);
  const planColor: Record<string, string> = { baze: "#3b82f6", plus: "#a855f7", premium: "#f97316", free: "#71717a" };
  const subState = getSubscriptionState(business as unknown as Record<string, unknown>);
  const isSubscribed = subState.active;
  const isAdvanced = subState.active && subState.plan === "advanced";
  const isPro = hasStats(effPlan, "full");
  const isAdvancedOrPro = hasStats(effPlan, "charts") || isAdvanced;
  const atLimit = effPlan.maxProducts !== null && productCount >= effPlan.maxProducts;
  const plan = subState.plan;
  const pc = subState.expired ? "#71717a" : planColor[plan] || "#71717a";
  const sum14 = (d: DayData[]) => [...d].sort((a, b) => a.date.localeCompare(b.date)).slice(-14).reduce((n, x) => n + x.count, 0);

  const pctChange = (now: number, prev: number) => {
    if (prev === 0) return now > 0 ? "+100%" : "—";
    const pct = Math.round(((now - prev) / prev) * 100);
    return pct >= 0 ? `+${pct}%` : `${pct}%`;
  };

  return (
    <div className="ov-root">

      {/* Hero */}
      <div className="ov-hero">
        <div className="ov-hero-left">
          <div className="ov-logo">
            {business.logo ? <img src={business.logo} alt={business.name} /> : <span>🏪</span>}
          </div>
          <div>
            <h1 className="ov-biz-name">{business.name}</h1>
            <p className="ov-biz-meta">{business.category} · {business.city}</p>
          </div>
        </div>
        <span className="ov-plan-badge" style={{ background: `${pc}18`, color: pc, borderColor: `${pc}40` }}>
          {subState.label}{subState.expired ? " · skaduar" : ""}
        </span>
      </div>

      {/* Përmbledhja: çfarë solli NearBuy këtë muaj */}
      {isSubscribed && hasStats(effPlan, "monthly") && comparison && (
        <div className="ov-summary">
          <p className="ov-summary-title">Këtë muaj NearBuy të solli</p>
          <p className="ov-summary-text">
            <b>{comparison.thisMonth.views}</b> shikime të profilit dhe produkteve
            {" · "}<b>{comparison.thisMonth.contacts}</b> klientë që të kontaktuan
          </p>
        </div>
      )}

      {/* Abonimi ka skaduar */}
      {subState.expired && (
        <div className="ov-banner ov-banner-red">
          <span>⚠</span>
          <div style={{ flex: 1 }}>
            <p className="ov-banner-title" style={{ color: "#f87171" }}>
              Abonimi {subState.label} skadoi{subState.endDate ? ` më ${formatDate(subState.endDate)}` : ""}
            </p>
            <p className="ov-banner-sub" style={{ color: "#a1a1aa" }}>
              Produktet e tua nuk renditen më lart dhe statistikat janë të mbyllura. Rinovo që të mos humbasësh klientët.
            </p>
          </div>
          {!(business.planStatus === "pending" && business.requestedPlan) && (
            <button className="ov-renew-btn" disabled={requesting} onClick={() => handleRequestPlan(plan)}>
              Rinovo {subState.label}
            </button>
          )}
        </div>
      )}
      {!subState.expired && subState.active && subState.daysLeft !== null && subState.daysLeft <= 7 && (
        <div className="ov-banner ov-banner-yellow">
          <span>⏰</span>
          <div>
            <p className="ov-banner-title" style={{ color: "#f5c842" }}>Abonimi skadon për {subState.daysLeft} ditë</p>
            <p className="ov-banner-sub" style={{ color: "#a1a1aa" }}>Rinovo që profili të mos ndalet.</p>
          </div>
        </div>
      )}

      {/* Banners */}
      {!business.verified && (
        <div className="ov-banner">
          <span>⏳</span>
          <div>
            <p className="ov-banner-title">Llogaria në pritje aprovimi</p>
            <p className="ov-banner-sub">Ekipi ynë do të shqyrtojë biznesin tënd brenda 24 orëve.</p>
          </div>
        </div>
      )}
      {business.planStatus === "pending" && business.requestedPlan && (
        <div className="ov-banner ov-banner-blue">
          <span>📋</span>
          <div>
            <p className="ov-banner-title" style={{ color: "#93c5fd" }}>Kërkesë plani në pritje</p>
            <p className="ov-banner-sub" style={{ color: "#1e3a5f" }}>
              Ke kërkuar paketën <strong style={{ color: "#93c5fd" }}>{PLAN_DEFS[normalizePlanId(business.requestedPlan)].name}</strong>. Ekipi ynë do ta aprovojë së shpejti.
            </p>
          </div>
        </div>
      )}
      {!isSubscribed && !subState.expired && !(business.planStatus === "pending" && business.requestedPlan) && (
        <div className="ov-banner ov-banner-yellow">
          <span>ℹ️</span>
          <div>
            <p className="ov-banner-title" style={{ color: "#f5c842" }}>Je në paketën Falas · {productCount}/{effPlan.maxProducts} produkte</p>
            <p className="ov-banner-sub" style={{ color: "#a1a1aa" }}>Kalo te Bazë (€10/muaj) për deri në 300 produkte, ngarkim me Excel dhe oferta.</p>
          </div>
        </div>
      )}

      {/* Stats row */}
      <div className="ov-stats">
        <div className="ov-stat">
          <span className="ov-stat-icon">🛍</span>
          <div>
            <p className="ov-stat-val">{productCount}</p>
            <p className="ov-stat-label">Produkte</p>
          </div>
        </div>
        <div className="ov-stat">
          <span className="ov-stat-icon">👁</span>
          <div>
            <p className="ov-stat-val">{totalViews.toLocaleString()}</p>
            <p className="ov-stat-label">Shikime gjithsej</p>
          </div>
        </div>
        <div className="ov-stat">
          <span className="ov-stat-icon">📞</span>
          <div>
            <p className="ov-stat-val">{totalContacts.toLocaleString()}</p>
            <p className="ov-stat-label">Kontakte gjithsej</p>
          </div>
        </div>
        {isAdvancedOrPro && (
          <div className="ov-stat">
            <span className="ov-stat-icon">🗺</span>
            <div>
              <p className="ov-stat-val">{totalMaps.toLocaleString()}</p>
              <p className="ov-stat-label">Klikime Maps (30 ditë)</p>
            </div>
          </div>
        )}
      </div>

      {/* Analytics — Advanced+ */}
      {isAdvancedOrPro && (
        <div className="ov-section-title">Statistikat — 14 ditët e fundit</div>
      )}
      {isAdvancedOrPro && (
        <div className="ov-charts">
          <div className="ov-chart-card">
            <p className="ov-chart-title">👁 Shikime</p>
            <p className="ov-chart-total">{sum14(viewsData).toLocaleString()}</p>
            <MiniChart data={viewsData} color="#a855f7" />
          </div>
          <div className="ov-chart-card">
            <p className="ov-chart-title">📞 Kontakte</p>
            <p className="ov-chart-total">{sum14(contactsData).toLocaleString()}</p>
            <MiniChart data={contactsData} color="#22c55e" />
          </div>
          <div className="ov-chart-card">
            <p className="ov-chart-title">🗺 Maps</p>
            <p className="ov-chart-total">{sum14(mapsData).toLocaleString()}</p>
            <MiniChart data={mapsData} color="#f5c842" />
          </div>
        </div>
      )}

      {/* Pro — Krahasim periudhash */}
      {isPro && comparison && (
        <>
          <div className="ov-section-title">Krahasim — Ky muaj vs muaji i kaluar</div>
          <div className="ov-compare">
            <div className="ov-compare-card">
              <p className="ov-compare-label">👁 Shikime këtë muaj</p>
              <p className="ov-compare-val">{comparison.thisMonth.views}</p>
              <p className="ov-compare-change" style={{ color: comparison.thisMonth.views >= comparison.lastMonth.views ? "#22c55e" : "#f87171" }}>
                {pctChange(comparison.thisMonth.views, comparison.lastMonth.views)} nga muaji i kaluar
              </p>
            </div>
            <div className="ov-compare-card">
              <p className="ov-compare-label">📞 Kontakte këtë muaj</p>
              <p className="ov-compare-val">{comparison.thisMonth.contacts}</p>
              <p className="ov-compare-change" style={{ color: comparison.thisMonth.contacts >= comparison.lastMonth.contacts ? "#22c55e" : "#f87171" }}>
                {pctChange(comparison.thisMonth.contacts, comparison.lastMonth.contacts)} nga muaji i kaluar
              </p>
            </div>
          </div>
        </>
      )}

      {/* Çfarë kërkojnë klientët — mbushet vetë me kalimin e kohës */}
      <MarketInsights
        businessId={business.id}
        city={business.city}
        categories={Array.isArray((business as any).categories) && (business as any).categories.length ? (business as any).categories : business.category ? [business.category] : []}
        myProductIds={myProductIds}
        level={hasStats(effPlan, "charts") ? "market" : hasStats(effPlan, "monthly") ? "own" : "none"}
      />

      {/* Quick actions */}
      <div className="ov-section-title">Veprime të shpejta</div>
      <div className="ov-actions">
        {!atLimit ? (
          <Link href="/dashboard/business/products" className="ov-action">
            <span className="ov-action-icon">➕</span>
            <div>
              <p className="ov-action-title">Shto produkt</p>
              <p className="ov-action-sub">
                {effPlan.maxProducts === null ? "Pa limit" : `${productCount}/${effPlan.maxProducts} produkte`}
              </p>
            </div>
          </Link>
        ) : (
          <div className="ov-action ov-action-locked">
            <span className="ov-action-icon">🔒</span>
            <div>
              <p className="ov-action-title">Shto produkt</p>
              <p className="ov-action-sub">Ke arritur limitin {productCount}/{effPlan.maxProducts}. Kalo te një paketë më e madhe.</p>
            </div>
          </div>
        )}
        <Link href="/dashboard/business/profile" className="ov-action">
          <span className="ov-action-icon">✏️</span>
          <div>
            <p className="ov-action-title">Edito profilin</p>
            <p className="ov-action-sub">Ndrysho të dhënat e dyqanit</p>
          </div>
        </Link>
      </div>

      {/* Paketat */}
      <div className="ov-section-title">Paketat</div>
      <div className="ov-plans">
        {PLAN_ORDER.map(id => {
          const p = PLAN_DEFS[id];
          const isCurrentPlan = effPlan.id === id;
          const isPending = normalizePlanId(business.requestedPlan) === id && business.planStatus === "pending" && id !== "free";
          return (
            <div key={id} className={`ov-plan ${isCurrentPlan ? "ov-plan-active" : ""}`}
              style={{ borderColor: isCurrentPlan ? `${p.color}60` : isPending ? `${p.color}40` : undefined }}>
              {id === "plus" && !isCurrentPlan && <div className="ov-plan-tag" style={{ background: p.color }}>Më e zgjedhura</div>}
              {isCurrentPlan && <div className="ov-plan-tag" style={{ background: p.color }}>Paketa jote</div>}
              {isPending && !isCurrentPlan && <div className="ov-plan-tag" style={{ background: "#52525b" }}>Në pritje</div>}
              <div className="ov-plan-header">
                <p className="ov-plan-name" style={{ color: p.color }}>{p.name}</p>
                <div className="ov-plan-price">
                  <span className="ov-plan-amount">{formatEur(p.priceEur)}</span>
                  {p.priceEur > 0 && <span className="ov-plan-currency">/muaj</span>}
                </div>
              </div>
              <div className="ov-plan-features">
                {p.perks.map(f => (
                  <div key={f} className="ov-plan-feat">
                    <span className="ov-feat-check" style={{ color: p.color }}>✓</span>
                    <span>{f}</span>
                  </div>
                ))}
              </div>
              {id !== "free" && (
                <button onClick={() => handleRequestPlan(id)}
                  disabled={requesting || isCurrentPlan || isPending}
                  className="ov-plan-btn"
                  style={isCurrentPlan || isPending ? {} : { background: p.color, boxShadow: `0 4px 20px ${p.color}40` }}>
                  {isCurrentPlan ? "Paketa aktuale" : isPending ? "⏳ Në pritje" : requestedSuccess === id ? "✓ Kërkesa u dërgua!" : "Zgjidh këtë paketë"}
                </button>
              )}
            </div>
          );
        })}
      </div>
      <p className="ov-plans-note">Pas kërkesës do të të kontaktojmë për pagesën. Paketa aktivizohet sapo të konfirmohet pagesa.</p>

      <style>{`
        .ov-root{display:flex;flex-direction:column;gap:1.25rem;max-width:820px}
        .ov-hero{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:1.25rem}
        .ov-hero-left{display:flex;align-items:center;gap:14px}
        .ov-logo{width:52px;height:52px;border-radius:12px;background:rgba(249,115,22,0.1);border:1px solid rgba(249,115,22,0.2);display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0;overflow:hidden}
        .ov-logo img{width:100%;height:100%;object-fit:cover}
        .ov-biz-name{font-size:1.15rem;font-weight:700;color:#f4f4f5;letter-spacing:-0.02em}
        .ov-biz-meta{font-size:0.8rem;color:#71717a;margin-top:2px}
        .ov-plan-badge{font-size:0.72rem;font-weight:600;padding:3px 10px;border-radius:6px;border:1px solid}
        .ov-banner{display:flex;align-items:flex-start;gap:12px;background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.2);border-radius:12px;padding:1rem}
        .ov-banner-blue{background:rgba(59,130,246,0.08);border-color:rgba(59,130,246,0.2)}
        .ov-banner-yellow{background:rgba(245,200,66,0.06);border-color:rgba(245,200,66,0.2)}
        .ov-banner-red{background:rgba(239,68,68,0.06);border-color:rgba(239,68,68,0.25);align-items:center;flex-wrap:wrap}
        .ov-renew-btn{padding:0.55rem 1.1rem;background:#f97316;color:#fff;border:none;border-radius:10px;font-size:0.85rem;font-weight:600;cursor:pointer;font-family:inherit;white-space:nowrap}
        .ov-renew-btn:disabled{opacity:0.5}
        .ov-summary{background:linear-gradient(135deg,rgba(249,115,22,0.12),rgba(245,200,66,0.06));border:1px solid rgba(249,115,22,0.25);border-radius:14px;padding:1rem 1.25rem}
        .ov-summary-title{font-size:0.75rem;font-weight:600;color:#f97316;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:4px}
        .ov-summary-text{font-size:1rem;color:#e4e4e7;line-height:1.5}
        .ov-summary-text b{color:#fff;font-size:1.15rem}
        .ov-banner span:first-child{font-size:1.2rem;margin-top:1px}
        .ov-banner-title{font-size:0.875rem;font-weight:600;color:#fbbf24}
        .ov-banner-sub{font-size:0.78rem;color:#92400e;margin-top:2px}
        .ov-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
        .ov-stat{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:1rem}
        .ov-stat-icon{font-size:1.3rem}
        .ov-stat-val{font-size:1.3rem;font-weight:700;color:#f4f4f5;line-height:1}
        .ov-stat-label{font-size:0.72rem;color:#71717a;margin-top:3px}
        .ov-section-title{font-size:0.75rem;font-weight:600;color:#52525b;text-transform:uppercase;letter-spacing:0.05em}
        .ov-charts{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
        .ov-chart-card{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:1rem}
        .ov-chart-title{font-size:0.78rem;font-weight:600;color:#a1a1aa;margin-bottom:4px}
        .ov-chart-total{font-size:1.4rem;font-weight:800;color:#f4f4f5;letter-spacing:-0.02em;margin-bottom:10px}
        .chart-bars{display:flex;align-items:flex-end;gap:3px;height:60px}
        .chart-bar-wrap{flex:1;height:100%;display:flex;align-items:flex-end}
        .chart-bar{width:100%;border-radius:3px 3px 0 0;min-height:2px;transition:height .3s}
        .chart-empty{font-size:0.75rem;color:#52525b;text-align:center;padding:1rem 0}
        .ov-compare{display:grid;grid-template-columns:1fr 1fr;gap:12px}
        .ov-compare-card{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:1rem}
        .ov-compare-label{font-size:0.78rem;color:#71717a;margin-bottom:6px}
        .ov-compare-val{font-size:1.6rem;font-weight:800;color:#f4f4f5;letter-spacing:-0.03em;margin-bottom:4px}
        .ov-compare-change{font-size:0.75rem;font-weight:600}
        .ov-top-products{display:flex;flex-direction:column;gap:8px}
        .ov-top-prod{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:10px;padding:0.75rem 1rem}
        .ov-top-rank{font-size:0.85rem;font-weight:800;color:#f97316;width:28px;flex-shrink:0}
        .ov-top-name{font-size:0.875rem;font-weight:600;color:#e4e4e7;flex:1}
        .ov-top-count{font-size:0.75rem;color:#71717a}
        .ov-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px}
        .ov-action{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:1rem;text-decoration:none;transition:border-color .2s,background .2s}
        .ov-action:hover{border-color:rgba(249,115,22,0.3);background:rgba(249,115,22,0.05)}
        .ov-action-locked{opacity:0.4;cursor:not-allowed}
        .ov-action-icon{font-size:1.3rem}
        .ov-action-title{font-size:0.875rem;font-weight:600;color:#e4e4e7}
        .ov-action-sub{font-size:0.75rem;color:#71717a;margin-top:1px}
        .ov-plans{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
        .ov-plans-note{font-size:0.78rem;color:#71717a;margin-top:-0.5rem}
        .ov-plan{position:relative;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:1.25rem;display:flex;flex-direction:column;gap:1rem;transition:border-color .2s}
        .ov-plan-active{background:rgba(255,255,255,0.05)}
        .ov-plan-tag{position:absolute;top:-10px;left:50%;transform:translateX(-50%);font-size:0.68rem;font-weight:700;color:white;padding:2px 10px;border-radius:20px;white-space:nowrap}
        .ov-plan-header{margin-top:6px}
        .ov-plan-name{font-size:0.85rem;font-weight:700;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:4px}
        .ov-plan-price{display:flex;align-items:baseline;gap:4px}
        .ov-plan-amount{font-size:1.6rem;font-weight:800;color:#f4f4f5;letter-spacing:-0.03em}
        .ov-plan-currency{font-size:0.78rem;color:#71717a}
        .ov-plan-features{display:flex;flex-direction:column;gap:6px;flex:1}
        .ov-plan-feat{display:flex;align-items:center;gap:8px;font-size:0.78rem;color:#a1a1aa}
        .ov-feat-check{font-size:0.75rem;width:14px;flex-shrink:0}
        .ov-feat-no{opacity:0.35}
        .ov-feat-no .ov-feat-check{color:#71717a}
        .ov-plan-btn{width:100%;padding:0.6rem;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:10px;color:white;font-size:0.8rem;font-weight:600;cursor:pointer;font-family:inherit;transition:opacity .2s,transform .15s}
        .ov-plan-btn:hover:not(:disabled){opacity:0.85;transform:translateY(-1px)}
        .ov-plan-btn:disabled{opacity:0.6;cursor:not-allowed;transform:none}
        @media(max-width:900px){.ov-plans{grid-template-columns:1fr 1fr}}
        @media(max-width:700px){.ov-stats{grid-template-columns:1fr 1fr}.ov-charts,.ov-plans{grid-template-columns:1fr}.ov-compare,.ov-actions{grid-template-columns:1fr}}
      `}</style>
    </div>
  );
}
